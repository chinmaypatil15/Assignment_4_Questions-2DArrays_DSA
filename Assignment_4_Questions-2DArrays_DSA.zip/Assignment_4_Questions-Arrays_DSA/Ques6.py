def sortedSquares(nums):
    left = 0
    right = len(nums) - 1
    result = []
    while left <= right:
        square_left = nums[left] * nums[left]
        square_right = nums[right] * nums[right]
        if square_left > square_right:
            result.append(square_left)
            left += 1
        else:
            result.append(square_right)
            right -= 1
    while right >= 0:
        result.append(nums[right] * nums[right])
        right -= 1
    return result[::-1]
# Test example
nums = [-4, -1, 0, 3, 10]
result = sortedSquares(nums)
print(result)
