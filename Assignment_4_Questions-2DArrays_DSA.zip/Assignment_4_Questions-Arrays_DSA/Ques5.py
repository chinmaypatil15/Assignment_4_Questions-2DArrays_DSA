def arrangeCoins(n):
    k = 0
    total_coins = 0
    while total_coins <= n:
        k += 1
        total_coins = k * (k + 1) // 2
    return k - 1
# Test example
n = 5
result = arrangeCoins(n)
print(result)
