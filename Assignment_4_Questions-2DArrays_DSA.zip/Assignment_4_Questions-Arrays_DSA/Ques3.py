def transpose(matrix):
    transpose = []
    for column in range(len(matrix[0])):
        row = []
        for row_idx in range(len(matrix)):
            row.append(matrix[row_idx][column])
        transpose.append(row)
    return transpose
# Test example
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
result = transpose(matrix)
print(result)