def DisappearedNumbers(nums1, nums2):
    set1 = set(nums1)
    set2 = set(nums2)
    answer = []
    distinct_nums_in_nums1 = [num for num in nums1 if num not in set2]
    distinct_nums_in_nums2 = [num for num in nums2 if num not in set1]
    answer.append(distinct_nums_in_nums1)
    answer.append(distinct_nums_in_nums2)
    return answer
# Test example
nums1 = [1, 2, 3]
nums2 = [2, 4, 6]
result = DisappearedNumbers(nums1, nums2)
print(result)